package pmd_Prueba;

import java.util.ArrayList;
import java.util.LinkedList;

public class PMDPrueba {
	public static void main(String[] args) {
		int x, y;
		String nombre = "Pepe";
		ArrayList<Integer> resultado = new ArrayList<>();
		
		x = 5;
		y = 3;
		resultado.add(x);
		resultado.add(y);
		
		try {
			for(int i=0; i<resultado.size(); i++) {
				System.out.println("El numero es: "+ resultado.get(i));
			}
		}catch (Exception e) {
			
		}
	}
}
